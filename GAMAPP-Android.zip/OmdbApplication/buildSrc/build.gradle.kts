repositories {
    mavenCentral()
}

plugins {
    `kotlin-dsl`
}